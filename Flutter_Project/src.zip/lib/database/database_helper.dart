import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import '../models/holding.dart';

class DatabaseHelper {
  static final DatabaseHelper _instance = DatabaseHelper._internal();
  factory DatabaseHelper() => _instance;
  DatabaseHelper._internal();

  static Database? _database;

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDB();
    return _database!;
  }

  Future<Database> _initDB() async {
    String path = join(await getDatabasesPath(), 'holdings.db');
    return await openDatabase(
      path,
      version: 1,
      onCreate: (db, version) {
        return db.execute('''
          CREATE TABLE holdings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            stockSymbol TEXT NOT NULL,
            quantity INTEGER NOT NULL,
            purchasePrice REAL NOT NULL
          )
        ''');
      },
    );
  }

  Future<int> insertHolding(Holding holding) async {
    final db = await database;
    return await db.insert('holdings', holding.toMap());
  }

  Future<List<Holding>> getHoldings() async {
    final db = await database;
    final List<Map<String, dynamic>> holdings = await db.query('holdings');
    return holdings.map((map) => Holding.fromMap(map)).toList();
  }

  Future<void> deleteHolding(int id) async {
    final db = await database;
    await db.delete('holdings', where: 'id = ?', whereArgs: [id]);
  }

  Future<void> updateHoldingQuantity(int id, int newQuantity) async {
    final db = await database;
    await db.update(
      'holdings',
      {'quantity': newQuantity},
      where: 'id = ?',
      whereArgs: [id],
    );
  }
}
