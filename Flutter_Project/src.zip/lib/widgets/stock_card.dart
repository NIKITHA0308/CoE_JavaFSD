import 'package:flutter/material.dart';

class StockCard extends StatelessWidget {
  final Map<String, String> stock;

  const StockCard({super.key, required this.stock});

  @override
  Widget build(BuildContext context) {
    return Card(
      color: Colors.black54,
      elevation: 5,
      margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 12),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(
          vertical: 12, // Slightly more padding for better spacing
          horizontal: 18,
        ),
        leading: const Icon(
          Icons.trending_up,
          color: Colors.greenAccent,
          size: 28,
        ), // Bigger icon
        title: Text(
          stock['company']!,
          style: const TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 18, // Increased from default (16)
            color: Colors.white,
          ),
        ),
        subtitle: Text(
          "Symbol: ${stock['symbol']}",
          style: const TextStyle(
            fontSize: 16, // Increased from default (14)
            color: Colors.white70,
          ),
        ),
        trailing: const Icon(
          Icons.arrow_forward_ios,
          color: Colors.white70,
          size: 18, // Slightly bigger trailing icon
        ),
      ),
    );
  }
}
