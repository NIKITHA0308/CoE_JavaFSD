import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class PortfolioScreen extends StatefulWidget {
  const PortfolioScreen({super.key});

  @override
  PortfolioScreenState createState() => PortfolioScreenState();
}

class PortfolioScreenState extends State<PortfolioScreen> {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Stream<QuerySnapshot> _getTransactions() {
    return _firestore
        .collection('portfolio')
        .orderBy('timestamp', descending: true)
        .snapshots();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: const Text(
          "Portfolio",
          style: TextStyle(
            fontSize: 22,
            fontWeight: FontWeight.bold,
            color: Colors.white, // White title text
          ),
        ),
        backgroundColor: Colors.black87,
        elevation: 4,
        iconTheme: const IconThemeData(
          color: Colors.white, // White back arrow
        ),
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: _getTransactions(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(
              child: CircularProgressIndicator(color: Colors.greenAccent),
            );
          }
          if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
            return const Center(
              child: Text(
                "No transactions found",
                style: TextStyle(
                  fontSize: 18,
                  color: Colors.white70,
                  fontWeight: FontWeight.bold,
                ),
              ),
            );
          }

          final transactions = snapshot.data!.docs;

          return ListView.builder(
            itemCount: transactions.length,
            itemBuilder: (context, index) {
              var transaction = transactions[index];
              return Card(
                color: Colors.black87, // Dark card background
                margin: const EdgeInsets.all(8),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                  side: const BorderSide(color: Colors.greenAccent, width: 1),
                ),
                child: ListTile(
                  leading: const Icon(
                    Icons.trending_up,
                    color: Colors.greenAccent,
                    size: 28,
                  ),
                  title: Text(
                    "Stock: ${transaction['stockSymbol']}",
                    style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                  subtitle: Text(
                    "Buyer: ${transaction['name']}\nQuantity: ${transaction['quantity']}",
                    style: const TextStyle(fontSize: 14, color: Colors.white70),
                  ),
                  trailing: Text(
                    transaction['timestamp'] != null
                        ? DateTime.fromMillisecondsSinceEpoch(
                          transaction['timestamp'].seconds * 1000,
                        ).toLocal().toString()
                        : "N/A",
                    style: const TextStyle(
                      fontSize: 12,
                      color: Colors.greenAccent,
                    ),
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
