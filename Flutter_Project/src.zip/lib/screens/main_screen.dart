import 'package:flutter/material.dart';
import 'home_screen.dart';
import 'portfolio_screen.dart';
import 'holdings_screen.dart';
import 'news_screen.dart';

class MainScreen extends StatefulWidget {
  final Function(Locale) onLocaleChange;

  const MainScreen({super.key, required this.onLocaleChange});

  @override
  MainScreenState createState() => MainScreenState();
}

class MainScreenState extends State<MainScreen> {
  int _selectedIndex = 0;
  late final List<Widget> _pages;

  @override
  void initState() {
    super.initState();
    _pages = [
      HomeScreen(),
      const PortfolioScreen(),
      const HoldingsScreen(),
      NewsScreen(onLocaleChange: widget.onLocaleChange),
    ];
  }

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF121212), // Soft black background
      appBar: AppBar(
        title: const Text(
          "STOCK UP AND GROW",
          style: TextStyle(
            color: Colors.white, // Makes title visible
            fontSize: 20, // Slightly bigger text for emphasis
            fontWeight: FontWeight.bold, // Enhances readability
          ),
        ),
        backgroundColor: const Color.fromARGB(
          255,
          0,
          0,
          0,
        ), // Dark grey for contrast
        centerTitle: true,
        elevation: 2,
        iconTheme: const IconThemeData(
          color: Colors.white,
        ), // Ensures icons are visible
      ),
      body: _pages[_selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: const Color.fromARGB(
          255,
          0,
          0,
          0,
        ), // Dark but not harsh
        currentIndex: _selectedIndex,
        onTap: _onItemTapped,
        type: BottomNavigationBarType.fixed,
        selectedItemColor:
            Colors.greenAccent.shade200, // Softer green highlight
        unselectedItemColor:
            Colors.redAccent.shade200, // Soft red for inactive items
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
          BottomNavigationBarItem(
            icon: Icon(Icons.pie_chart),
            label: 'Portfolio',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.account_balance_wallet),
            label: 'Holdings',
          ),
          BottomNavigationBarItem(icon: Icon(Icons.article), label: 'News'),
        ],
      ),
    );
  }
}
