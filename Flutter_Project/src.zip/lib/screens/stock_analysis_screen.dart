import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;

class StockAnalysisScreen extends StatefulWidget {
  final String stockSymbol;

  const StockAnalysisScreen({super.key, required this.stockSymbol});

  @override
  StockAnalysisScreenState createState() => StockAnalysisScreenState();
}

class StockAnalysisScreenState extends State<StockAnalysisScreen> {
  List<FlSpot> priceData = [];
  double minY = 0, maxY = 100; // Default Y-axis range

  @override
  void initState() {
    super.initState();
    _fetchStockHistory();
  }

  Future<void> _fetchStockHistory() async {
    final String apiUrl =
        "https://67d2950390e0670699be320a.mockapi.io/api/v1/currentprice"; // Replace with actual API

    try {
      final response = await http.get(Uri.parse(apiUrl));
      if (response.statusCode == 200) {
        List<dynamic> data = jsonDecode(response.body);
        List<FlSpot> tempData = [];

        double minPrice = double.infinity;
        double maxPrice = double.negativeInfinity;

        for (int i = 0; i < data.length; i++) {
          if (data[i]['symbol'] == widget.stockSymbol) {
            double price = data[i]['price'].toDouble();
            tempData.add(FlSpot(i.toDouble(), price));

            if (price < minPrice) minPrice = price;
            if (price > maxPrice) maxPrice = price;
          }
        }

        if (tempData.isNotEmpty) {
          setState(() {
            priceData = tempData;
            minY = minPrice * 0.95; // Add some padding
            maxY = maxPrice * 1.05;
          });
        } else {
          throw Exception('No data found for this stock');
        }
      } else {
        throw Exception('Failed to load stock history');
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            backgroundColor: Colors.redAccent,
            content: Text(
              'Error fetching stock history: ${e.toString()}',
              style: const TextStyle(color: Colors.white),
            ),
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: Text(
          "Stock Analysis: ${widget.stockSymbol}",
          style: const TextStyle(
            fontSize: 22,
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
        backgroundColor: Colors.black87,
        elevation: 4,
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: Center(
        child:
            priceData.isEmpty
                ? const CircularProgressIndicator(color: Colors.greenAccent)
                : Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: LineChart(
                    LineChartData(
                      minY: minY,
                      maxY: maxY,
                      titlesData: FlTitlesData(
                        leftTitles: AxisTitles(
                          sideTitles: SideTitles(
                            showTitles: true,
                            reservedSize: 50,
                            getTitlesWidget:
                                (value, meta) => Text(
                                  value.toStringAsFixed(2),
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 16, // **Increased font size**
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                          ),
                        ),
                        bottomTitles: AxisTitles(
                          sideTitles: SideTitles(
                            showTitles: true,
                            reservedSize: 50,
                            getTitlesWidget:
                                (value, meta) => Text(
                                  "T${value.toInt()}",
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 16, // **Increased font size**
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                          ),
                        ),
                      ),
                      gridData: FlGridData(
                        show: true,
                        getDrawingHorizontalLine:
                            (value) =>
                                FlLine(color: Colors.white24, strokeWidth: 0.8),
                        getDrawingVerticalLine:
                            (value) =>
                                FlLine(color: Colors.white24, strokeWidth: 0.8),
                      ),
                      borderData: FlBorderData(
                        show: true,
                        border: Border.all(color: Colors.white38, width: 1),
                      ),
                      lineBarsData: [
                        LineChartBarData(
                          spots: priceData,
                          isCurved: true,
                          color: Colors.greenAccent,
                          barWidth: 3,
                          isStrokeCapRound: true,
                          belowBarData: BarAreaData(
                            show: true,
                            color: Colors.greenAccent.withAlpha(
                              (0.3 * 255).toInt(),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
      ),
    );
  }
}
