import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;
import '../database/database_helper.dart';
import '../models/holding.dart';
import 'stock_analysis_screen.dart';

class HoldingsScreen extends StatefulWidget {
  const HoldingsScreen({super.key});

  @override
  HoldingsScreenState createState() => HoldingsScreenState();
}

class HoldingsScreenState extends State<HoldingsScreen> {
  late DatabaseHelper dbHelper;
  List<Holding> holdings = [];
  Map<String, double> currentPrices = {};

  @override
  void initState() {
    super.initState();
    dbHelper = DatabaseHelper();
    _loadHoldings();
  }

  Future<void> _loadHoldings() async {
    List<Holding> data = await dbHelper.getHoldings();
    setState(() {
      holdings = data;
    });
    await _fetchCurrentPrices();
  }

  Future<void> _fetchCurrentPrices() async {
    const String apiUrl =
        "https://67d2950390e0670699be320a.mockapi.io/api/v1/currentprice";

    try {
      final response = await http.get(Uri.parse(apiUrl));
      if (response.statusCode == 200) {
        List<dynamic> data = jsonDecode(response.body);
        setState(() {
          for (var stock in data) {
            currentPrices[stock['symbol']] = stock['price'].toDouble();
          }
        });
      } else {
        throw Exception('Failed to load stock prices');
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error fetching stock prices: ${e.toString()}'),
          ),
        );
      }
    }
  }

  Future<void> _sellStock(Holding holding) async {
    if (holding.quantity > 1) {
      await dbHelper.updateHoldingQuantity(holding.id!, holding.quantity - 1);
    } else {
      await dbHelper.deleteHolding(holding.id!);
    }
    _loadHoldings();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: const Text(
          "My Holdings",
          style: TextStyle(
            fontSize: 22,
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
        backgroundColor: Colors.black87,
        elevation: 4,
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body:
          holdings.isEmpty
              ? const Center(
                child: Text(
                  "No holdings available",
                  style: TextStyle(
                    fontSize: 18,
                    color: Colors.white70,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              )
              : ListView.builder(
                itemCount: holdings.length,
                itemBuilder: (context, index) {
                  final holding = holdings[index];
                  final currentPrice =
                      currentPrices[holding.stockSymbol] ?? 0.0;
                  final totalCost = holding.quantity * holding.purchasePrice;
                  final currentValue = holding.quantity * currentPrice;
                  final profitOrLoss = currentValue - totalCost;
                  final profitOrLossText =
                      profitOrLoss >= 0
                          ? 'Profit: ₹${profitOrLoss.toStringAsFixed(2)}'
                          : 'Loss: ₹${(-profitOrLoss).toStringAsFixed(2)}';

                  return Card(
                    color: Colors.black87,
                    margin: const EdgeInsets.all(8),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                      side: const BorderSide(
                        color: Colors.greenAccent,
                        width: 1,
                      ),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(12.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "Stock: ${holding.stockSymbol}",
                            style: const TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 18,
                              color: Colors.white,
                            ),
                          ),
                          const SizedBox(height: 5),
                          Text(
                            "Quantity: ${holding.quantity}",
                            style: const TextStyle(color: Colors.white70),
                          ),
                          Text(
                            "Purchase Price: ₹${holding.purchasePrice}",
                            style: const TextStyle(color: Colors.white70),
                          ),
                          Text(
                            "Total Cost: ₹${totalCost.toStringAsFixed(2)}",
                            style: const TextStyle(color: Colors.white70),
                          ),
                          Text(
                            "Current Price: ₹${currentPrice.toStringAsFixed(2)}",
                            style: const TextStyle(color: Colors.white70),
                          ),
                          Text(
                            profitOrLossText,
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 16,
                              color:
                                  profitOrLoss >= 0
                                      ? Colors.greenAccent
                                      : Colors.redAccent,
                            ),
                          ),
                          const SizedBox(height: 10),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              ElevatedButton(
                                onPressed: () => _sellStock(holding),
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: Colors.redAccent,
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                ),
                                child: const Text(
                                  "Sell",
                                  style: TextStyle(color: Colors.white),
                                ),
                              ),
                              ElevatedButton(
                                onPressed: () {
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder:
                                          (context) => StockAnalysisScreen(
                                            stockSymbol: holding.stockSymbol,
                                          ),
                                    ),
                                  );
                                },
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: Colors.blueAccent,
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                ),
                                child: const Text(
                                  "Inspect",
                                  style: TextStyle(color: Colors.white),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
    );
  }
}
