import 'package:flutter/material.dart';
import 'stock_details_screen.dart';
import '../widgets/stock_card.dart';

class HomeScreen extends StatelessWidget {
  HomeScreen({super.key});

  final List<Map<String, String>> stocks = [
    {"symbol": "RELIANCE", "company": "Reliance Industries Ltd."},
    {"symbol": "TCS", "company": "Tata Consultancy Services"},
    {"symbol": "INFY", "company": "Infosys Ltd."},
    {"symbol": "HDFCBANK", "company": "HDFC Bank Ltd."},
    {"symbol": "ICICIBANK", "company": "ICICI Bank Ltd."},
    {"symbol": "HINDUNILVR", "company": "Hindustan Unilever Ltd."},
    {"symbol": "KOTAKBANK", "company": "Kotak Mahindra Bank Ltd."},
    {"symbol": "BHARTIARTL", "company": "Bharti Airtel Ltd."},
    {"symbol": "LT", "company": "Larsen & Toubro Ltd."},
    {"symbol": "SBIN", "company": "State Bank of India"},
    {"symbol": "MARUTI", "company": "Maruti Suzuki India Ltd."},
    {"symbol": "BAJFINANCE", "company": "Bajaj Finance Ltd."},
    {"symbol": "ASIANPAINT", "company": "Asian Paints Ltd."},
    {"symbol": "WIPRO", "company": "Wipro Ltd."},
    {"symbol": "ULTRACEMCO", "company": "UltraTech Cement Ltd."},
  ];

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        // Background Image
        Positioned.fill(
          child: Image.asset('assets/bg_stock_market.jpg', fit: BoxFit.cover),
        ),
        // Overlay for readability
        Positioned.fill(
          child: Container(
            color: const Color.fromARGB(
              153,
              0,
              0,
              0,
            ), // Replaces withOpacity(0.6)
          ),
        ),
        // Stock List
        ListView.builder(
          itemCount: stocks.length,
          itemBuilder: (context, index) {
            var stock = stocks[index];
            return GestureDetector(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder:
                        (context) =>
                            StockDetailsScreen(symbol: stock['symbol']!),
                  ),
                );
              },
              child: StockCard(stock: stock),
            );
          },
        ),
      ],
    );
  }
}
