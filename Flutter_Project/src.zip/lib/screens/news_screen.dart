import 'package:flutter/material.dart';
import '../localization.dart';

class NewsScreen extends StatefulWidget {
  final Function(Locale)? onLocaleChange;

  const NewsScreen({super.key, this.onLocaleChange});

  @override
  NewsScreenState createState() => NewsScreenState();
}

class NewsScreenState extends State<NewsScreen> {
  Locale _selectedLocale = const Locale('en');

  void _changeLanguage(Locale newLocale) {
    setState(() {
      _selectedLocale = newLocale;
    });
    widget.onLocaleChange?.call(newLocale);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black, // Dark Background
      appBar: AppBar(
        title: Text(
          AppLocalizations.of(context).translate('news_title'),
          style: const TextStyle(
            fontSize: 24,
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ), // Large White Text
        ),
        backgroundColor: Colors.black, // Dark AppBar
        actions: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10),
            child: DropdownButton<Locale>(
              value: _selectedLocale,
              dropdownColor: Colors.grey[900], // Dark Dropdown Background
              onChanged: (Locale? newValue) {
                if (newValue != null) {
                  _changeLanguage(newValue);
                }
              },
              underline: Container(),
              icon: const Icon(Icons.language, color: Colors.white),
              items: const [
                DropdownMenuItem(
                  value: Locale('en'),
                  child: Text('English', style: TextStyle(color: Colors.white)),
                ),
                DropdownMenuItem(
                  value: Locale('es'),
                  child: Text('Español', style: TextStyle(color: Colors.white)),
                ),
                DropdownMenuItem(
                  value: Locale('fr'),
                  child: Text(
                    'Français',
                    style: TextStyle(color: Colors.white),
                  ),
                ),
                DropdownMenuItem(
                  value: Locale('ta'),
                  child: Text('தமிழ்', style: TextStyle(color: Colors.white)),
                ),
                DropdownMenuItem(
                  value: Locale('hi'),
                  child: Text('हिन्दी', style: TextStyle(color: Colors.white)),
                ),
              ],
            ),
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              AppLocalizations.of(context).translate('latest_news'),
              textAlign: TextAlign.center,
              style: const TextStyle(
                fontSize: 26,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ), // Large White Text
            ),
            const SizedBox(height: 20),

            // News Cards
            Expanded(
              child: ListView.builder(
                itemCount: 5,
                itemBuilder: (context, index) {
                  return Card(
                    color: Colors.grey[900], // Dark Card Background
                    elevation: 5,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                    margin: const EdgeInsets.symmetric(vertical: 10),
                    child: Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: Text(
                        AppLocalizations.of(
                          context,
                        ).translate('news_${index + 1}'),
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w500,
                          color: Colors.white, // White Text
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
