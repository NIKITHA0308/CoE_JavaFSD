import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;
import '../database/database_helper.dart';
import '../models/holding.dart';

class BuyerDetailsScreen extends StatefulWidget {
  final String stockSymbol;
  const BuyerDetailsScreen({super.key, required this.stockSymbol});

  @override
  BuyerDetailsScreenState createState() => BuyerDetailsScreenState();
}

class BuyerDetailsScreenState extends State<BuyerDetailsScreen> {
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _quantityController = TextEditingController();
  bool _isStockBought = false;
  final DatabaseHelper dbHelper = DatabaseHelper();
  double? stockPrice; // Updated to store the fetched stock price

  @override
  void initState() {
    super.initState();
    _fetchStockPrice();
  }

  // Function to fetch stock price from API
  Future<void> _fetchStockPrice() async {
    const String apiUrl =
        "https://67d2950390e0670699be320a.mockapi.io/api/v1/authors";

    try {
      final response = await http.get(Uri.parse(apiUrl));
      if (response.statusCode == 200) {
        List<dynamic> data = jsonDecode(response.body);
        var stockData = data.firstWhere(
          (item) => item["symbol"] == widget.stockSymbol,
          orElse: () => null,
        );

        if (stockData != null) {
          setState(() {
            stockPrice = double.tryParse(
              stockData['price'].toString(),
            ); // Convert to double
          });
        } else {
          setState(() {
            stockPrice = null;
          });
        }
      }
    } catch (e) {
      setState(() {
        stockPrice = null;
      });
    }
  }

  Future<void> _saveToDatabase() async {
    String name = _nameController.text.trim();
    int? quantity = int.tryParse(_quantityController.text);

    if (name.isEmpty ||
        quantity == null ||
        quantity <= 0 ||
        stockPrice == null) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Please enter valid details!')),
        );
      }
      return;
    }

    double totalCost = quantity * stockPrice!;

    try {
      await FirebaseFirestore.instance.collection('portfolio').add({
        'name': name,
        'stockSymbol': widget.stockSymbol,
        'quantity': quantity,
        'purchasePrice': stockPrice,
        'totalCost': totalCost,
        'timestamp': FieldValue.serverTimestamp(),
      });

      // Save to SQLite (Holdings)
      await dbHelper.insertHolding(
        Holding(
          stockSymbol: widget.stockSymbol,
          quantity: quantity,
          purchasePrice: stockPrice!,
        ),
      );

      setState(() {
        _isStockBought = true;
      });

      _nameController.clear();
      _quantityController.clear();

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Stock purchased successfully!')),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text('Error: ${e.toString()}')));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: Text(
          "Buy ${widget.stockSymbol}",
          style: const TextStyle(
            fontSize: 22,
            fontWeight: FontWeight.bold,
            color: Colors.white, // Title text in white
          ),
        ),
        backgroundColor: Colors.black87,
        elevation: 4,
        iconTheme: const IconThemeData(
          color: Colors.white, // Back arrow color
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (stockPrice == null)
              const Center(
                child: CircularProgressIndicator(color: Colors.greenAccent),
              )
            else ...[
              Text(
                "Current Price: ₹${stockPrice!.toStringAsFixed(2)}",
                style: const TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: Colors.greenAccent, // Price color
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: _nameController,
                style: const TextStyle(color: Colors.white), // Input text color
                decoration: InputDecoration(
                  labelText: 'Your Name',
                  labelStyle: const TextStyle(color: Colors.white70),
                  enabledBorder: OutlineInputBorder(
                    borderSide: const BorderSide(color: Colors.white70),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderSide: const BorderSide(color: Colors.greenAccent),
                  ),
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: _quantityController,
                style: const TextStyle(color: Colors.white),
                decoration: InputDecoration(
                  labelText: 'Stock Quantity',
                  labelStyle: const TextStyle(color: Colors.white70),
                  enabledBorder: OutlineInputBorder(
                    borderSide: const BorderSide(color: Colors.white70),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderSide: const BorderSide(color: Colors.greenAccent),
                  ),
                ),
                keyboardType: TextInputType.number,
              ),
              const SizedBox(height: 20),
              Center(
                child: ElevatedButton(
                  onPressed: _saveToDatabase,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.greenAccent, // Button color
                    foregroundColor: Colors.black, // Text color
                    padding: const EdgeInsets.symmetric(
                      horizontal: 24,
                      vertical: 12,
                    ),
                    textStyle: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  child: const Text("Confirm Purchase"),
                ),
              ),
              const SizedBox(height: 20),
              if (_isStockBought)
                const Center(
                  child: Text(
                    "Stock Bought & Saved!",
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: Colors.greenAccent,
                    ),
                  ),
                ),
            ],
          ],
        ),
      ),
    );
  }
}
