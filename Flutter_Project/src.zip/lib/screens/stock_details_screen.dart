import 'package:flutter/material.dart';
import 'buyer_details_screen.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;

class StockDetailsScreen extends StatefulWidget {
  final String symbol;
  const StockDetailsScreen({super.key, required this.symbol});

  @override
  StockDetailsScreenState createState() => StockDetailsScreenState();
}

class StockDetailsScreenState extends State<StockDetailsScreen> {
  Map<String, dynamic>? stock;
  bool isLoading = true;
  bool hasError = false;

  @override
  void initState() {
    super.initState();
    fetchStockDetails();
  }

  Future<void> fetchStockDetails() async {
    const String apiUrl =
        "https://67d2950390e0670699be320a.mockapi.io/api/v1/authors";

    try {
      final response = await http.get(Uri.parse(apiUrl));
      if (response.statusCode == 200) {
        List<dynamic> data = jsonDecode(response.body);
        var stockData = data.firstWhere(
          (item) => item["symbol"] == widget.symbol,
          orElse: () => null,
        );

        if (stockData != null) {
          setState(() {
            stock = stockData;
            isLoading = false;
          });
        } else {
          setState(() {
            hasError = true;
            isLoading = false;
          });
        }
      } else {
        setState(() {
          hasError = true;
          isLoading = false;
        });
      }
    } catch (e) {
      setState(() {
        hasError = true;
        isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: Text(
          widget.symbol,
          style: const TextStyle(
            fontSize: 22,
            fontWeight: FontWeight.bold,
            color: Colors.white, // Title text color set to white
          ),
        ),
        backgroundColor: Colors.black87,
        elevation: 4,
        iconTheme: const IconThemeData(
          color: Colors.white, // Back arrow color set to white
        ),
      ),
      body:
          isLoading
              ? const Center(
                child: CircularProgressIndicator(color: Colors.greenAccent),
              )
              : hasError
              ? const Center(
                child: Text(
                  "Failed to load stock data",
                  style: TextStyle(fontSize: 18, color: Colors.redAccent),
                ),
              )
              : Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Company: ${stock!['company']}",
                      style: const TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                    const SizedBox(height: 12),
                    Text(
                      "Price: ₹${stock!['price']}",
                      style: const TextStyle(
                        fontSize: 18,
                        color: Colors.greenAccent,
                      ),
                    ),
                    const SizedBox(height: 10),
                    Text(
                      "Change: ₹${stock!['change']} (${stock!['percentageChange']}%)",
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color:
                            stock!['percentageChange'] >= 0
                                ? Colors.green
                                : Colors.redAccent,
                      ),
                    ),
                    const SizedBox(height: 10),
                    Text(
                      "Market Cap: ${stock!['marketCap']}",
                      style: const TextStyle(
                        fontSize: 18,
                        color: Colors.white70,
                      ),
                    ),
                    const SizedBox(height: 10),
                    Text(
                      "Volume: ${stock!['volume']}",
                      style: const TextStyle(
                        fontSize: 18,
                        color: Colors.white70,
                      ),
                    ),
                    const SizedBox(height: 20),
                    Center(
                      child: ElevatedButton(
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder:
                                  (context) => BuyerDetailsScreen(
                                    stockSymbol: widget.symbol,
                                  ),
                            ),
                          );
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.greenAccent, // Button color
                          foregroundColor: Colors.black, // Text color
                          padding: const EdgeInsets.symmetric(
                            horizontal: 24,
                            vertical: 12,
                          ),
                          textStyle: const TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        child: const Text("Buy Stock"),
                      ),
                    ),
                  ],
                ),
              ),
    );
  }
}
