class Holding {
  final int? id;
  final String stockSymbol;
  final int quantity;
  final double purchasePrice;

  Holding({
    this.id,
    required this.stockSymbol,
    required this.quantity,
    required this.purchasePrice,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'stockSymbol': stockSymbol,
      'quantity': quantity,
      'purchasePrice': purchasePrice,
    };
  }

  factory Holding.fromMap(Map<String, dynamic> map) {
    return Holding(
      id: map['id'],
      stockSymbol: map['stockSymbol'],
      quantity: map['quantity'],
      purchasePrice: map['purchasePrice'],
    );
  }
}
