import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ApiService {

  constructor(private http: HttpClient) { }

  getServices(): Observable<any[]> {
    return this.http.get<any[]>('http://localhost:4500/services');
  }

  getDetails(id: string): Observable<any> {
    return this.http.get(`http://localhost:4500/details?id=${id}`);
  }

  addToCart(item: any): Observable<any> {
    return this.http.post('http://localhost:4500/cart', item);
  }

  getCart(): Observable<any[]> {
    return this.http.get<any[]>('http://localhost:4500/cart');
  }

 
  placeOrder(order: any): Observable<any> {
    return this.http.post('http://localhost:4500/orders', order);
  }

  getOrders(): Observable<any[]> {
    return this.http.get<any[]>('http://localhost:4500/orders');
  }

  getOffers(): Observable<any[]> {
    return this.http.get<any[]>('http://localhost:4500/offers');
  }
 
}
