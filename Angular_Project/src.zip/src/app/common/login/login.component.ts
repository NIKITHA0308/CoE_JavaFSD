import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  username: string = '';
  password: string = '';

  constructor(private router: Router) {}

  login(): void {
    if (this.username === 'Nikitha' && this.password === '123') {
      localStorage.setItem('username', this.username);
      this.router.navigate(['']).then(() => {
        window.location.reload(); 
      });
    } else {
      alert('Invalid Credentials');
    }
  }
}
