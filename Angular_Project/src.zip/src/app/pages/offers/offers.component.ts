import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../services/api.service';

@Component({
  selector: 'app-offers',
  templateUrl: './offers.component.html',
  styleUrls: ['./offers.component.css']
})
export class OffersComponent implements OnInit {
  offers: any[] = [];

  constructor(private api: ApiService) {}

  ngOnInit(): void {
    this.api.getOffers().subscribe({
      next: (data: any[]) => {
        this.offers = data;
      },
      error: err => console.error('Error fetching offers:', err)
    });
  }

 
}
