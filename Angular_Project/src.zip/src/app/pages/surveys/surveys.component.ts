import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-surveys',
  templateUrl: './surveys.component.html',
  styleUrls: ['./surveys.component.css']
})
export class SurveysComponent implements OnInit {
  surveyData = {
    name: '',
    email: '',
    feedback: '',
    rating: 0 
  };
  surveys: any[] = [];

  constructor(private http: HttpClient) {}

  ngOnInit() {
    this.fetchSurveys();
  }

  submitSurvey() {
    if (!this.surveyData.name || !this.surveyData.email || !this.surveyData.feedback || this.surveyData.rating === 0) {
      alert('Please fill out all fields and provide a rating.');
      return;
    }

    this.http.post('http://localhost:4500/surveys', this.surveyData).subscribe(response => { 
      console.log('Survey submitted:', response);
      alert('Survey submitted successfully!');
      this.surveyData = { name: '', email: '', feedback: '', rating: 0 }; 
      this.fetchSurveys();
    });
  }

  fetchSurveys() {
    this.http.get<any[]>('http://localhost:4500/surveys').subscribe(data => { 
      this.surveys = data;
    });
  }

  setRating(star: number) {
    this.surveyData.rating = star;
  }
}
