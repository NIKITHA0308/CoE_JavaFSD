import { Component, OnInit } from '@angular/core'; 
import { ApiService } from '../../services/api.service';
 @Component({ selector: 'app-cart', 
    templateUrl: './cart.component.html',
     styleUrls: ['./cart.component.css'] }) 
     export class CartComponent implements OnInit 
     { cart: any[] = []; total = 0; 
        constructor(private api: ApiService) {} 
        ngOnInit(): void { this.api.getCart().subscribe({ next: (data: any[]) => 
            { this.cart = data; this.calculateTotal(); },
             error: err => console.error(err) }); } 
             
             calculateTotal() { this.total = this.cart.reduce((sum, item) =>
                 sum + item.price * item.quantity, 0); } 
                 
            applyOffer() 
                 { this.api.getOffers().subscribe({ next: (offers: any[]) =>
                     { if (offers.length > 0) 
                        { const discount = offers[0].discount; 
                            if (discount <= 100) { 
                                this.total -= (this.total * discount) / 100; } 
                                else { this.total -= discount; } 
                                alert('Offer applied successfully!'); } },
                                 error: err => console.error(err) }); } 
                                 
            orderNow() { const order = { items: this.cart, total: this.total }; this.api.placeOrder(order).subscribe({ next: () => 
                                    { alert('Order placed successfully!'); 
                                        this.cart = []; this.total = 0; }, 
                                        error: err => console.error(err) }); } }