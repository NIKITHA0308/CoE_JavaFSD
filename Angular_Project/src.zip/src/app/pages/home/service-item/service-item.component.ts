import { Component, Input } from '@angular/core';
import { service } from '../../../model/service';
import { Router } from '@angular/router';
import { ApiService } from '../../../services/api.service';

@Component({
  selector: 'app-service-item',
  templateUrl: './service-item.component.html',
  styleUrls: ['./service-item.component.css']
})
export class ServiceItemComponent {
  @Input() service!: service;

  constructor(private router: Router, private api: ApiService) {}

  showDetails() {
    this.router.navigate(['/services', this.service.id], { state: { title: this.service.title } });
  }

  addToCart() {
    const cartItem = {
      id: this.service.id,
      title: this.service.title,
      price: this.service.price,
      quantity: 1
    };

    this.api.addToCart(cartItem).subscribe({
      next: () => alert(`${this.service.title} added to cart!`),
      error: err => console.error(err)
    });
  }
}
