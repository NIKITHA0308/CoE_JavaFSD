import { ItemHighlightPipe } from './item-highlight.pipe';

describe('ItemHighlightPipe', () => {
  it('create an instance', () => {
    const pipe = new ItemHighlightPipe();
    expect(pipe).toBeTruthy();
  });
});
