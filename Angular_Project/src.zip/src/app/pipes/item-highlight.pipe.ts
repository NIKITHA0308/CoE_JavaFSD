import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'itemHighlight'
})
export class ItemHighlightPipe implements PipeTransform {

  transform(value: string): string {
    const starIcon = '★';
    const formattedValue = value.trim();
    const uppercasedValue = formattedValue.toUpperCase();
    return `${starIcon} ${uppercasedValue}`;
}
}
