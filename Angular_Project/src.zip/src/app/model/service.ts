export interface service{
    id:string,
    title:string,
    description:string,
    image:string,
    price:number
}