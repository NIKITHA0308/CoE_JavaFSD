import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { ServiceDetailsComponent } from './pages/home/service-details/service-details.component';
import { LoginComponent } from './common/login/login.component';
import { OrdersComponent } from './pages/orders/orders.component';
import { HomeComponent } from './pages/home/home.component';
import { SurveysComponent } from './pages/surveys/surveys.component';
import { CartComponent } from './pages/cart/cart.component';
import { OffersComponent } from './pages/offers/offers.component';
import { ordersGuard } from './guards/orders.guard';

const routes: Routes = [
  {path:'',component:HomeComponent},
  {path:'login',component:LoginComponent},
  {path:'services/:id',component:ServiceDetailsComponent},
  {path:'orders',component:OrdersComponent,canActivate:[ordersGuard]},
  {path:'surveys',component:SurveysComponent},
  {path:'cart',component:CartComponent,canActivate:[ordersGuard]},
  {path:'offers',component:OffersComponent},
]

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
