import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MenuBarComponent } from './common/menu-bar/menu-bar.component';
import { LoginComponent } from './common/login/login.component';
import { OrdersComponent } from './pages/orders/orders.component';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HomeComponent } from './pages/home/home.component';
import { ServiceItemComponent } from './pages/home/service-item/service-item.component';
import { ServiceDetailsComponent } from './pages/home/service-details/service-details.component';
import { SurveysComponent } from './pages/surveys/surveys.component';
import { CartComponent } from './pages/cart/cart.component';
import { OffersComponent } from './pages/offers/offers.component';

import { ItemHighlightPipe } from './pipes/item-highlight.pipe';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    MenuBarComponent,
          LoginComponent,
          OrdersComponent,
        
          ServiceItemComponent,
          ServiceDetailsComponent,
          SurveysComponent,
          CartComponent,
          OffersComponent,
  
          ItemHighlightPipe
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
